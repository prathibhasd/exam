-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2024 at 12:26 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_mcq`
--

-- --------------------------------------------------------

--
-- Table structure for table `mcq_q_a`
--

CREATE TABLE `mcq_q_a` (
  `Id` int(100) NOT NULL,
  `question` varchar(300) NOT NULL,
  `option1` varchar(50) NOT NULL,
  `option2` varchar(50) NOT NULL,
  `option3` varchar(50) NOT NULL,
  `option4` varchar(50) NOT NULL,
  `correct_ans` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mcq_q_a`
--

INSERT INTO `mcq_q_a` (`Id`, `question`, `option1`, `option2`, `option3`, `option4`, `correct_ans`) VALUES
(1, 'Out of all the 2-digit integers between 1 and 100, a 2-digit number has to be selected at random. What is the probability that the selected number is not divisible by 7?', '13', '12', '14', '15', '13'),
(2, 'If the difference between expectation of the square of a random variable (E[X²]) and the square of the expectation of the random variable (E[X])² is denoted by R, then?', 'R = 0', 'R < 0', 'R >= 0', 'R > 0', 'R >= 0'),
(3, 'A deck of 5 cards (each carrying a distinct number from 1 to 5) is shuffled thoroughly. Two cards are then removed one at time from the deck. What is the probability that the two cards are selected with the number on the first card being one higher than the number on the second card?', '1/5', '4/25', '1/4', '2/5', '4/25'),
(4, 'Choose the most appropriate word from the options given below to complete the following sentence.', 'Hyperbolic', 'Restrained', 'Argumentative', 'Indifferent', 'Restrained'),
(5, 'Choose the most appropriate word from the options given below to complete the following sentence: If we manage to ____________ our natural resources, we would leave a better planet for our children.', 'uphold', 'restrain', 'cherish', 'conserve', 'restrain'),
(6, 'Let X be a random variable following normal distribution with mean +1 and variance 4. Let Y be another normal variable with mean -1 and variance unknown If P(X <=-1) = P(Y >=2). the standard deviation of Y is', 'sqrt(2)', '1', '2', '3', '2'),
(7, 'Choose the most appropriate word from the options given below to complete the following sentence. He could not understand the judges awarding her the first prize, because he thought that her performance was quite __________.', 'superb', 'medium', 'mediocre', 'exhilarating', ''),
(8, 'The probability that a given positive integer lying between 1 and 100 (both inclusive) is NOT divisible by 2, 3 or 5 is ______ .', '0.259', '0.459', '0.325', '0.225', '0.459'),
(9, '500 was invested at 12% per annum simple interest and a certain sum of money invested at 10% per annum simple interest. If the sum of the interest on both the sum after 4 years is 480, the latter sum of money is ?', '450 ', '750 ', '600', '550 ', '750 '),
(10, 'A man took a loan from a bank at the rate of 12% per annum at simple interest. After 3 years he had to pay 5,400 as interest only for the period. The principal amount borrowed by him was ?', '2,000', '10000', '5000', '8000', '5000'),
(11, 'In simple interest rate per annum a certain sum amounts to Rs. 5,182 in 2 years and Rs. 5,832 in 3 years. The principal in rupees is ?', 'Rs. 2882 ', 'Rs. 5000 ', 'Rs. 3882 ', 'Rs. 4000 ', 'Rs. 5000 '),
(12, 'If the simple interest for 6 years be equal to 30% of the principal, it will be equal to the principal after ?', '20 years ', '30 years ', '40 years ', '60 years ', '20 years '),
(13, 'The rate of simple interest per annum at which a sum of money doubles itself in 16 and 2/3 years is ?', '4 % ', '5% ', '6% ', '7 % ', '4 % '),
(14, '6,000 becomes 7,200 in 4 years at a certain rate of simple interest. If the rate becomes 1.5 times of itself, the amount of the same principal in 5 years will be ?', '8,000', '8,250 ', '9,250 ', '9,000', '8,250 '),
(15, 'If the simple interest on Re. 1 for 1 month is 1 paisa, then the rate per cent per annum will be ?', '10% ', '8%', '12%', '6% ', '8%'),
(16, 'The sum lent at 5% per annum (i.e. 365 days) simple interest, that produces interest, of 2.00 a day, is ?', '1,400 ', '14,700', '14,600 ', '7,300 ', '14,700'),
(17, '	In how many years will a sum of 3,000 yield a simple interest of 1,080 at 12% per annum ?', '3 years ', '2 and 1/2 years ', '2 years', '3 and 1/2 years ', '2 and 1/2 years '),
(18, 'What sum of money will amount to 520 in 5 years and to 568 in 7 years at simple interest ?', '400 ', '120', '510 ', '220 ', '120'),
(19, 'A certain sum of money amounts to Rs. 2200 at 5% p.a. rate of interest, Rs. 2320 at 8% interest in the same period of time. The period of time is ?', '3 years ', '4 years', '5 year', '2 years ', '4 years'),
(20, 'The simple interest on a sum for 5 years is one fourth of the sum. The rate of interest per annum is ?', '5%', '6%', '4% ', '8%', '6%'),
(21, '	Mohan lent some amount of money at 9% simple interest and an equal amount of money at 10% simple interest each for two years. If his total interest was Rs. 760, what amount was lent in each case ?', '1700', '1800 ', '1900 ', '2000 ', '1800 ');

-- --------------------------------------------------------

--
-- Table structure for table `question_answer`
--

CREATE TABLE `question_answer` (
  `Id` int(11) NOT NULL,
  `question1` varchar(200) NOT NULL,
  `answer1` varchar(200) NOT NULL,
  `question2` varchar(200) NOT NULL,
  `answer2` varchar(200) NOT NULL,
  `question3` varchar(100) NOT NULL,
  `answer3` varchar(100) NOT NULL,
  `question4` varchar(100) NOT NULL,
  `answer4` varchar(100) NOT NULL,
  `question5` varchar(100) NOT NULL,
  `answer5` varchar(100) NOT NULL,
  `question6` varchar(100) NOT NULL,
  `answer6` varchar(100) NOT NULL,
  `question7` varchar(100) NOT NULL,
  `answer7` varchar(100) NOT NULL,
  `question8` varchar(100) NOT NULL,
  `answer8` varchar(100) NOT NULL,
  `question9` varchar(100) NOT NULL,
  `answer9` varchar(100) NOT NULL,
  `question10` varchar(100) NOT NULL,
  `answer10` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `question_answer`
--

INSERT INTO `question_answer` (`Id`, `question1`, `answer1`, `question2`, `answer2`, `question3`, `answer3`, `question4`, `answer4`, `question5`, `answer5`, `question6`, `answer6`, `question7`, `answer7`, `question8`, `answer8`, `question9`, `answer9`, `question10`, `answer10`) VALUES
(1, '0', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(2, '1', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(3, '2', '3', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(4, '3', '3', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(5, '4', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(6, '5', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(7, '6', '3', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(8, '7', '3', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(9, '8', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(10, '9', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(11, '5', '3', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(12, '6', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(13, '7', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(14, '8', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(15, '9', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(16, '0', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(17, '0', '3', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(18, '1', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(19, '2', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(20, '3', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(21, '4', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(22, '5', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(23, '6', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(24, '7', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(25, '8', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(26, '9', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(27, '0', '3', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(28, '1', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(29, '2', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(30, '3', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(31, '4', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(32, '5', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(33, '6', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(34, '7', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(35, '8', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(36, '9', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(37, '0', '3', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(38, '1', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(39, '2', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(40, '3', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(41, '4', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(42, '5', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(43, '6', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(44, '7', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(45, '8', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(46, '9', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(47, '0', '3', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(48, '1', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(49, '2', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(50, '3', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(51, '4', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(52, '5', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(53, '6', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(54, '7', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(55, '8', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(56, '9', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(57, '0', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(58, '1', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(59, '2', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(60, '3', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(61, '4', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(62, '5', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(63, '6', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(64, '7', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(65, '8', '1', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(66, '9', '0', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(67, '0', '3', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', ''),
(68, '1', '2', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `response`
--

CREATE TABLE `response` (
  `Id` int(10) NOT NULL,
  `q1` varchar(50) NOT NULL,
  `q2` varchar(50) NOT NULL,
  `q3` varchar(50) NOT NULL,
  `q4` varchar(50) NOT NULL,
  `q5` varchar(50) NOT NULL,
  `q6` varchar(50) NOT NULL,
  `q7` varchar(50) NOT NULL,
  `q8` varchar(50) NOT NULL,
  `q9` varchar(50) NOT NULL,
  `q10` varchar(50) NOT NULL,
  `q11` varchar(50) NOT NULL,
  `q12` varchar(50) NOT NULL,
  `q13` varchar(50) NOT NULL,
  `q14` varchar(50) NOT NULL,
  `q15` varchar(50) NOT NULL,
  `q16` varchar(50) NOT NULL,
  `q17` varchar(50) NOT NULL,
  `q18` varchar(50) NOT NULL,
  `q19` varchar(50) NOT NULL,
  `q20` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(100) NOT NULL,
  `email` varchar(100) NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `name`, `email`, `created_at`) VALUES
(1, '', '', '2024-03-06 05:27:29'),
(2, 'John Doe', 'john@example.com', '2024-03-06 05:27:31'),
(3, '', '', '2024-03-06 05:27:32'),
(4, '', '', '2024-03-06 05:27:37'),
(5, '', '', '2024-03-06 05:27:39'),
(6, 'John Doe', 'john@example.com', '2024-03-06 05:32:17'),
(7, 'John Doe', 'john@example.com', '2024-03-06 05:32:18'),
(8, 'John Doe', 'john@example.com', '2024-03-06 05:32:19'),
(9, 'John Doe', 'john@example.com', '2024-03-06 05:52:50'),
(10, 'John Doe', 'john@example.com', '2024-03-06 05:52:52'),
(11, 'John Doe', 'john@example.com', '2024-03-06 05:52:52'),
(12, 'John Doe', 'john@example.com', '2024-03-06 05:52:52'),
(13, 'John Doe', 'john@example.com', '2024-03-06 05:52:53'),
(14, 'John Doe', 'john@example.com', '2024-03-06 05:52:53'),
(15, 'John Doe', 'john@example.com', '2024-03-06 05:52:53'),
(16, 'John Doe', 'john@example.com', '2024-03-06 05:57:47'),
(17, 'John Doe', 'john@example.com', '2024-03-06 05:57:49');

-- --------------------------------------------------------

--
-- Table structure for table `user_answers`
--

CREATE TABLE `user_answers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `option_selected` int(11) DEFAULT NULL,
  `created_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user_answers`
--

INSERT INTO `user_answers` (`id`, `user_id`, `question_id`, `option_selected`, `created_at`) VALUES
(1, 9, 1, 3, '2024-03-06 05:52:50'),
(2, 9, 2, 2, '2024-03-06 05:52:50'),
(3, 9, 3, 2, '2024-03-06 05:52:50'),
(4, 9, 4, 2, '2024-03-06 05:52:50'),
(5, 9, 5, 1, '2024-03-06 05:52:50'),
(6, 9, 6, 2, '2024-03-06 05:52:50'),
(7, 9, 8, 1, '2024-03-06 05:52:50'),
(8, 9, 9, 3, '2024-03-06 05:52:50'),
(9, 9, 10, 3, '2024-03-06 05:52:50'),
(10, 10, 1, 3, '2024-03-06 05:52:52'),
(11, 10, 2, 2, '2024-03-06 05:52:52'),
(12, 10, 3, 2, '2024-03-06 05:52:52'),
(13, 10, 4, 2, '2024-03-06 05:52:52'),
(14, 10, 5, 1, '2024-03-06 05:52:52'),
(15, 10, 6, 2, '2024-03-06 05:52:52'),
(16, 10, 8, 1, '2024-03-06 05:52:52'),
(17, 10, 9, 3, '2024-03-06 05:52:52'),
(18, 10, 10, 3, '2024-03-06 05:52:52'),
(19, 11, 1, 3, '2024-03-06 05:52:52'),
(20, 11, 2, 2, '2024-03-06 05:52:52'),
(21, 11, 3, 2, '2024-03-06 05:52:52'),
(22, 11, 4, 2, '2024-03-06 05:52:52'),
(23, 11, 5, 1, '2024-03-06 05:52:52'),
(24, 11, 6, 2, '2024-03-06 05:52:52'),
(25, 11, 8, 1, '2024-03-06 05:52:52'),
(26, 11, 9, 3, '2024-03-06 05:52:52'),
(27, 11, 10, 3, '2024-03-06 05:52:52'),
(28, 12, 1, 3, '2024-03-06 05:52:52'),
(29, 12, 2, 2, '2024-03-06 05:52:52'),
(30, 12, 3, 2, '2024-03-06 05:52:52'),
(31, 12, 4, 2, '2024-03-06 05:52:52'),
(32, 12, 5, 1, '2024-03-06 05:52:52'),
(33, 12, 6, 2, '2024-03-06 05:52:52'),
(34, 12, 8, 1, '2024-03-06 05:52:52'),
(35, 12, 9, 3, '2024-03-06 05:52:52'),
(36, 12, 10, 3, '2024-03-06 05:52:52'),
(37, 13, 1, 3, '2024-03-06 05:52:53'),
(38, 13, 2, 2, '2024-03-06 05:52:53'),
(39, 13, 3, 2, '2024-03-06 05:52:53'),
(40, 13, 4, 2, '2024-03-06 05:52:53'),
(41, 13, 5, 1, '2024-03-06 05:52:53'),
(42, 13, 6, 2, '2024-03-06 05:52:53'),
(43, 13, 8, 1, '2024-03-06 05:52:53'),
(44, 13, 9, 3, '2024-03-06 05:52:53'),
(45, 13, 10, 3, '2024-03-06 05:52:53'),
(46, 14, 1, 3, '2024-03-06 05:52:53'),
(47, 14, 2, 2, '2024-03-06 05:52:53'),
(48, 14, 3, 2, '2024-03-06 05:52:53'),
(49, 14, 4, 2, '2024-03-06 05:52:53'),
(50, 14, 5, 1, '2024-03-06 05:52:53'),
(51, 14, 6, 2, '2024-03-06 05:52:53'),
(52, 14, 8, 1, '2024-03-06 05:52:53'),
(53, 14, 9, 3, '2024-03-06 05:52:53'),
(54, 14, 10, 3, '2024-03-06 05:52:53'),
(55, 15, 1, 3, '2024-03-06 05:52:53'),
(56, 15, 2, 2, '2024-03-06 05:52:53'),
(57, 15, 3, 2, '2024-03-06 05:52:53'),
(58, 15, 4, 2, '2024-03-06 05:52:53'),
(59, 15, 5, 1, '2024-03-06 05:52:53'),
(60, 15, 6, 2, '2024-03-06 05:52:53'),
(61, 15, 8, 1, '2024-03-06 05:52:53'),
(62, 15, 9, 3, '2024-03-06 05:52:53'),
(63, 15, 10, 3, '2024-03-06 05:52:53'),
(64, 16, 2, 2, '2024-03-06 05:57:47'),
(65, 16, 3, 1, '2024-03-06 05:57:47'),
(66, 16, 4, 2, '2024-03-06 05:57:47'),
(67, 16, 5, 3, '2024-03-06 05:57:47'),
(68, 16, 6, 2, '2024-03-06 05:57:47'),
(69, 16, 9, 3, '2024-03-06 05:57:47'),
(70, 16, 10, 1, '2024-03-06 05:57:47'),
(71, 17, 2, 2, '2024-03-06 05:57:49'),
(72, 17, 3, 1, '2024-03-06 05:57:49'),
(73, 17, 4, 2, '2024-03-06 05:57:49'),
(74, 17, 5, 3, '2024-03-06 05:57:49'),
(75, 17, 6, 2, '2024-03-06 05:57:49'),
(76, 17, 9, 3, '2024-03-06 05:57:49'),
(77, 17, 10, 1, '2024-03-06 05:57:49');

-- --------------------------------------------------------

--
-- Table structure for table `user_responses`
--

CREATE TABLE `user_responses` (
  `id` int(11) NOT NULL,
  `user_id` int(11) DEFAULT NULL,
  `question_id` int(11) DEFAULT NULL,
  `selected_option` int(11) DEFAULT NULL,
  `submission_date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mcq_q_a`
--
ALTER TABLE `mcq_q_a`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `question_answer`
--
ALTER TABLE `question_answer`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `response`
--
ALTER TABLE `response`
  ADD PRIMARY KEY (`Id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `user_answers`
--
ALTER TABLE `user_answers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id` (`user_id`);

--
-- Indexes for table `user_responses`
--
ALTER TABLE `user_responses`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mcq_q_a`
--
ALTER TABLE `mcq_q_a`
  MODIFY `Id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `question_answer`
--
ALTER TABLE `question_answer`
  MODIFY `Id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=69;

--
-- AUTO_INCREMENT for table `response`
--
ALTER TABLE `response`
  MODIFY `Id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `user_answers`
--
ALTER TABLE `user_answers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=78;

--
-- AUTO_INCREMENT for table `user_responses`
--
ALTER TABLE `user_responses`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `user_answers`
--
ALTER TABLE `user_answers`
  ADD CONSTRAINT `user_answers_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
