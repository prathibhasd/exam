-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Mar 08, 2024 at 11:15 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `test_mcq`
--

-- --------------------------------------------------------

--
-- Table structure for table `mcq_q_a`
--

CREATE TABLE `mcq_q_a` (
  `Id` int(100) NOT NULL,
  `question` varchar(300) NOT NULL,
  `option1` varchar(50) NOT NULL,
  `option2` varchar(50) NOT NULL,
  `option3` varchar(50) NOT NULL,
  `option4` varchar(50) NOT NULL,
  `correct_ans` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `mcq_q_a`
--

INSERT INTO `mcq_q_a` (`Id`, `question`, `option1`, `option2`, `option3`, `option4`, `correct_ans`) VALUES
(1, 'Out of all the 2-digit integers between 1 and 100, a 2-digit number has to be selected at random. What is the probability that the selected number is not divisible by 7?', '13', '12', '14', '15', '13'),
(2, 'If the difference between expectation of the square of a random variable (E[X²]) and the square of the expectation of the random variable (E[X])² is denoted by R, then?', 'R = 0', 'R < 0', 'R >= 0', 'R > 0', 'R >= 0'),
(3, 'A deck of 5 cards (each carrying a distinct number from 1 to 5) is shuffled thoroughly. Two cards are then removed one at time from the deck. What is the probability that the two cards are selected with the number on the first card being one higher than the number on the second card?', '1/5', '4/25', '1/4', '2/5', '4/25'),
(4, 'Choose the most appropriate word from the options given below to complete the following sentence.', 'Hyperbolic', 'Restrained', 'Argumentative', 'Indifferent', 'Restrained'),
(5, 'Choose the most appropriate word from the options given below to complete the following sentence: If we manage to ____________ our natural resources, we would leave a better planet for our children.', 'uphold', 'restrain', 'cherish', 'conserve', 'restrain'),
(6, 'Let X be a random variable following normal distribution with mean +1 and variance 4. Let Y be another normal variable with mean -1 and variance unknown If P(X <=-1) = P(Y >=2). the standard deviation of Y is', 'sqrt(2)', '1', '2', '3', '2'),
(7, 'Choose the most appropriate word from the options given below to complete the following sentence. He could not understand the judges awarding her the first prize, because he thought that her performance was quite __________.', 'superb', 'medium', 'mediocre', 'exhilarating', ''),
(8, 'The probability that a given positive integer lying between 1 and 100 (both inclusive) is NOT divisible by 2, 3 or 5 is ______ .', '0.259', '0.459', '0.325', '0.225', '0.459'),
(9, '500 was invested at 12% per annum simple interest and a certain sum of money invested at 10% per annum simple interest. If the sum of the interest on both the sum after 4 years is 480, the latter sum of money is ?', '450 ', '750 ', '600', '550 ', '750 '),
(10, 'A man took a loan from a bank at the rate of 12% per annum at simple interest. After 3 years he had to pay 5,400 as interest only for the period. The principal amount borrowed by him was ?', '2,000', '10000', '5000', '8000', '5000'),
(11, 'In simple interest rate per annum a certain sum amounts to Rs. 5,182 in 2 years and Rs. 5,832 in 3 years. The principal in rupees is ?', 'Rs. 2882 ', 'Rs. 5000 ', 'Rs. 3882 ', 'Rs. 4000 ', 'Rs. 5000 '),
(12, 'If the simple interest for 6 years be equal to 30% of the principal, it will be equal to the principal after ?', '20 years ', '30 years ', '40 years ', '60 years ', '20 years '),
(13, 'The rate of simple interest per annum at which a sum of money doubles itself in 16 and 2/3 years is ?', '4 % ', '5% ', '6% ', '7 % ', '4 % '),
(14, '6,000 becomes 7,200 in 4 years at a certain rate of simple interest. If the rate becomes 1.5 times of itself, the amount of the same principal in 5 years will be ?', '8,000', '8,250 ', '9,250 ', '9,000', '8,250 '),
(15, 'If the simple interest on Re. 1 for 1 month is 1 paisa, then the rate per cent per annum will be ?', '10% ', '8%', '12%', '6% ', '8%'),
(16, 'The sum lent at 5% per annum (i.e. 365 days) simple interest, that produces interest, of 2.00 a day, is ?', '1,400 ', '14,700', '14,600 ', '7,300 ', '14,700'),
(17, '	In how many years will a sum of 3,000 yield a simple interest of 1,080 at 12% per annum ?', '3 years ', '2 and 1/2 years ', '2 years', '3 and 1/2 years ', '2 and 1/2 years '),
(18, 'What sum of money will amount to 520 in 5 years and to 568 in 7 years at simple interest ?', '400 ', '120', '510 ', '220 ', '120'),
(19, 'A certain sum of money amounts to Rs. 2200 at 5% p.a. rate of interest, Rs. 2320 at 8% interest in the same period of time. The period of time is ?', '3 years ', '4 years', '5 year', '2 years ', '4 years'),
(20, 'The simple interest on a sum for 5 years is one fourth of the sum. The rate of interest per annum is ?', '5%', '6%', '4% ', '8%', '6%'),
(21, '	Mohan lent some amount of money at 9% simple interest and an equal amount of money at 10% simple interest each for two years. If his total interest was Rs. 760, what amount was lent in each case ?', '1700', '1800 ', '1900 ', '2000 ', '1800 ');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `mcq_q_a`
--
ALTER TABLE `mcq_q_a`
  ADD PRIMARY KEY (`Id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `mcq_q_a`
--
ALTER TABLE `mcq_q_a`
  MODIFY `Id` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
