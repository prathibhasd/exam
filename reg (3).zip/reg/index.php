<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Online Aptitude Test</title>
</head>
<body>
    <h1>Online Aptitude Test</h1>
    <div id="questionsContainer"></div>
    <button onclick="submitAnswers()">Submit Answers</button>

    <script>
        // Store user's selected answers
        const userAnswers = {};
        // User details
        const userName = "John Doe"; // Example user name
        const userEmail = "john@example.com"; // Example user email

        // Function to submit answers
        function submitAnswers() {
            // Send userAnswers and user details to the server for processing
            const formData = new FormData();
            
            
            formData.append('userAnswers', JSON.stringify(userAnswers));

            fetch('submit_answers.php', {
                method: 'POST',
                body: formData
            })
            .then(response => response.text())
            .then(data => {
                console.log(data);
                // Handle success or display confirmation to the user
            })
            .catch(error => console.error('Error submitting answers:', error));
        }

        // Fetch questions from the backend PHP script
        fetch('fetch_questions.php')
            .then(response => response.json())
            .then(data => {
                const questionsContainer = document.getElementById('questionsContainer');
                // Iterate through fetched questions and display them
                data.forEach((question, index) => {
                    const questionDiv = document.createElement('div');
                    questionDiv.innerHTML = `
                        <p><strong>Question ${index + 1}: ${question.question}</strong></p>
                        <form id="questionForm${index}">
                            ${question.options.map((option, optionIndex) => `
                                <input type="radio" name="question${index}" value="${optionIndex}" onchange="recordAnswer(${index}, ${optionIndex})">
                                <label>${option}</label><br>
                            `).join('')}
                        </form>
                    `;
                    questionsContainer.appendChild(questionDiv);
                });
            })
            .catch(error => console.error('Error fetching questions:', error));

        // Function to record user's answer
        function recordAnswer(questionIndex, optionIndex) {
            userAnswers[questionIndex] = optionIndex;
        }
    </script>
</body>
</html>
