<?php
// Connect to your MySQL database
$servername = "localhost";
$username = "root"; // Change to your MySQL username
$password = ""; // Change to your MySQL password
$database = "test_mcq"; // Change to your database name

$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Fetch 10 random questions and options
$sql = "SELECT * FROM mcq_q_a ORDER BY RAND() LIMIT 10";
$result = $conn->query($sql);

// Store fetched data in an array
$questions = array();
while ($row = $result->fetch_assoc()) {
    $question = array(
        'question' => $row['question'],
        'options' => array(
            $row['option1'],
            $row['option2'],
            $row['option3'],
            $row['option4']
        )
    );
    $questions[] = $question;
}

// Close the database connection
$conn->close();

// Return questions data as JSON
header('Content-Type: application/json');
echo json_encode($questions);
?>
