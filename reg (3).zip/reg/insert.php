<?php
// Establish connection to MySQL
$mysqli = new mysqli("localhost", "root", "", "test_mcq");

// Check connection
if ($mysqli->connect_error) {
    die("Connection failed: " . $mysqli->connect_error);
}

// Assuming user_id is obtained through authentication
$user_id = 1; // For example

// Loop through submitted answers and insert into the database
for ($i = 1; $i <= 10; $i++) {
    // Assuming the question IDs are sequential from 1 to 10
    $question_id = $mysqli->real_escape_string($i);
    $user_answer = $mysqli->real_escape_string($_POST["question$i"]);

    // Insert user answers into the database
    $query = "INSERT INTO question_answer ( question1, answer1) VALUES ( '$question_id', '$user_answer')";
    $mysqli->query($query);
}

// Close connection
$mysqli->close();

// Redirect user to some page indicating submission success
header("Location: submission_success.php");
?>
