<?php
// Connect to your MySQL database
/*$servername = "localhost";
$username = "root"; // Change to your MySQL username
$password = ""; // Change to your MySQL password
$database = "test_mcq"; // Change to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user details from the frontend (for demonstration purposes, you can adapt this based on your actual implementation)
$userName = $_POST['userName'];
$userEmail = $_POST['userEmail'];

// Insert user details into the users table
$sql = "INSERT INTO users (name, email) VALUES ('$userName', '$userEmail')";
if ($conn->query($sql) === FALSE) {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Get the ID of the last inserted user
$userId = $conn->insert_id;

// Get user's answers from the frontend (assuming the answers are sent as an array)
$userAnswers = json_decode($_POST['userAnswers'], true);

// Loop through user's answers and insert them into the user_answers table
foreach ($userAnswers as $questionIndex => $optionIndex) {
    // Add 1 to questionIndex because questions are 1-indexed in the frontend
    $questionIndex++; 
    $optionSelected = $optionIndex + 1; // Add 1 to optionIndex because options are 1-indexed in the frontend
    $sql = "INSERT INTO user_answers (user_id, question_id, option_selected) VALUES ('$userId', '$questionIndex', '$optionSelected')";
    if ($conn->query($sql) === FALSE) {
        echo "Error: " . $sql . "<br>" . $conn->error;
    }
}

// Close the database connection
$conn->close();

echo "User answers submitted successfully!";*/
?>

<?php
// Connect to your MySQL database
$servername = "localhost";
$username = "root"; // Change to your MySQL username
$password = ""; // Change to your MySQL password
$database = "test_mcq"; // Change to your database name

// Create connection
$conn = new mysqli($servername, $username, $password, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get user's answers from the frontend (assuming the answers are sent as an array)
$userAnswers = json_decode($_POST['userAnswers'], true);

// Loop through user's answers and insert them into the question_answers table
//foreach ($userAnswers as $questionId => $answerValue) {
    //$sql = "INSERT INTO question_answer (question1, answer1) VALUES ('$questionId', '$answerValue')";
    //if ($conn->query($sql) === FALSE) {
        //echo "Error: " . $sql . "<br>" . $conn->error;
   // }
//}

for ($i = 1; $i <= 10; $i++) {
    // Assuming the question IDs are sequential from 1 to 10
    $question_id = $mysqli->real_escape_string($_POST["question{$i}"]);
    $answer_id = $mysqli->real_escape_string($_POST["answer{$i}"]);

    // Insert user answers into the database
    $query = "INSERT INTO user_answers (user_id, question_id, answer_id) VALUES ( '$question_id', '$answer_id')";
    $mysqli->query($query);
}


// Close the database connection
$conn->close();

echo "User answers submitted successfully!";
?>
